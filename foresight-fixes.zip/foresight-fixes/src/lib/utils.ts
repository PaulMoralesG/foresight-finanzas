// ================================================================
// UTILIDADES
// ================================================================

/**
 * Formatea un número como moneda MXN.
 */
export function formatMoney(amount: number): string {
  return new Intl.NumberFormat('es-MX', {
    style: 'currency',
    currency: 'MXN',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(roundMoney(amount));
}

/**
 * Redondeo aritmético seguro a 2 decimales para operaciones financieras (evita float drift IEEE 754).
 */
export function roundMoney(amount: number): number {
  return Math.round((amount + Number.EPSILON) * 100) / 100;
}

/**
 * Convierte un string de monto a número, aceptando tanto coma (,) como
 * punto (.) como separador decimal. Esto permite que usuarios en móviles
 * (iPhone con teclado de coma) y desktop (punto) ingresen montos sin fricción.
 *
 * Heurística:
 * - Si hay ambos (coma y punto), el último es el decimal
 * - Si solo hay coma y le siguen 1-2 dígitos al final → decimal
 * - Si solo hay punto y le siguen 1-2 dígitos al final → decimal
 * - En cualquier otro caso → separadores de miles (se eliminan)
 *
 * Ejemplos: "1,50"→1.5  "1,000"→1000  "60.70"→60.7  "1.000,50"→1000.5
 */
export function parseMoneyInput(raw: string): number {
  const trimmed = raw.trim();
  if (!trimmed) return 0;

  const hasComma = trimmed.includes(',');
  const hasDot = trimmed.includes('.');

  let normalized: string;

  if (hasComma && hasDot) {
    // Ambos presentes → el último es el decimal
    const lastComma = trimmed.lastIndexOf(',');
    const lastDot = trimmed.lastIndexOf('.');
    if (lastComma > lastDot) {
      // Coma es decimal, punto es miles
      normalized = trimmed.replace(/\./g, '').replace(',', '.');
    } else {
      // Punto es decimal, coma es miles
      normalized = trimmed.replace(/,/g, '');
    }
  } else if (hasComma) {
    // Solo coma: ¿decimal o miles?
    const lastCommaIdx = trimmed.lastIndexOf(',');
    const afterComma = trimmed.slice(lastCommaIdx + 1);
    // Si hay exactamente 1-2 dígitos después de la última coma → decimal
    if (/^\d{1,2}$/.test(afterComma) && trimmed.indexOf(',') === lastCommaIdx) {
      // Una sola coma con 1-2 dígitos después → decimal
      normalized = trimmed.replace(',', '.');
    } else {
      // Miles
      normalized = trimmed.replace(/,/g, '');
    }
  } else if (hasDot) {
    // Solo punto: ¿decimal o miles?
    const lastDotIdx = trimmed.lastIndexOf('.');
    const afterDot = trimmed.slice(lastDotIdx + 1);
    if (/^\d{1,2}$/.test(afterDot) && trimmed.indexOf('.') === lastDotIdx) {
      // Un solo punto con 1-2 dígitos después → decimal
      normalized = trimmed;
    } else {
      // Miles
      normalized = trimmed.replace(/\./g, '');
    }
  } else {
    normalized = trimmed;
  }

  const num = parseFloat(normalized);
  return isNaN(num) ? 0 : num;
}

/**
 * Obtiene la fecha de hoy en formato ISO local (YYYY-MM-DD).
 */
export function getTodayISO(): string {
  const today = new Date();
  const yyyy = today.getFullYear();
  const mm = String(today.getMonth() + 1).padStart(2, '0');
  const dd = String(today.getDate()).padStart(2, '0');
  return `${yyyy}-${mm}-${dd}`;
}

/**
 * Helper para sincronizar datos con el backend.
 * Muestra un toast de error si falla la sincronización.
 *
 * `saveData()` (syncService.schedule/flush) NUNCA rechaza — atrapa sus
 * propios errores de red/reintento y resuelve `false` en caso de fallo.
 * Antes este helper solo miraba `.catch()`, así que un push fallido tras
 * agotar los reintentos quedaba en silencio total. Ahora se revisa el
 * resultado booleano explícitamente.
 */
export function syncToCloud(
  saveData: () => Promise<boolean>,
  addToast: (msg: string, type: 'success' | 'error' | 'info') => void,
): void {
  saveData()
    .then((ok) => {
      if (!ok) {
        addToast('No se pudo guardar en la nube. Tus cambios quedaron solo en este dispositivo.', 'error');
      }
    })
    .catch((err: Error) => {
      console.error('[syncToCloud] Error al sincronizar:', err);
      addToast(err.message || 'Error al sincronizar con la nube', 'error');
    });
}

/**
 * Nombres de meses en español.
 */
export const MONTH_NAMES = Array.from({ length: 12 }, (_, i) => {
  const name = new Intl.DateTimeFormat('es-MX', { month: 'long' }).format(new Date(2024, i, 1));
  return name.charAt(0).toUpperCase() + name.slice(1);
});

/**
 * Parsea una fecha ISO (YYYY-MM-DD) de forma segura en todos los navegadores.
 * `new Date('2026-07-15')` falla en Safari; `new Date(y, m-1, d)` no.
 */
export function safeParseDate(iso: string): Date {
  // Tomar solo YYYY-MM-DD (soporta ISO completo: 2026-02-13T17:00:00.000Z)
  if (!iso || typeof iso !== 'string') return new Date();
  const datePart = iso.substring(0, 10);
  const [y, m, d] = datePart.split('-').map(Number);
  return new Date(y, m - 1, d);
}

/**
 * Formatea una fecha ISO en texto largo: "1 de Mayo 2026".
 * Parsea manualmente para evitar bugs de zona horaria (new Date(iso+'T00:00:00') trata como UTC).
 */
export function formatDateLong(iso: string): string {
  // Tomar solo YYYY-MM-DD (soporta ISO completo)
  const datePart = iso.substring(0, 10);
  const [year, month, day] = datePart.split('-').map(Number);
  return `${day} de ${MONTH_NAMES[month - 1]} ${year}`;
}

/**
 * Descarga un archivo.
 * - Móviles (iOS Safari, Android Chrome): Web Share API → menú nativo de
 *   compartir/guardar (WhatsApp, Archivos, AirDrop, etc.).
 * - Escritorio: blob URL + <a download>.
 */
export async function downloadBlob(blob: Blob, filename: string): Promise<void> {
  // Web Share API: funciona en iOS Safari 12.2+ y Android Chrome 75+
  if (navigator.share && navigator.canShare) {
    const file = new File([blob], filename, { type: blob.type || 'application/octet-stream' });
    if (navigator.canShare({ files: [file] })) {
      await navigator.share({ files: [file] });
      return;
    }
  }

  // Escritorio: blob URL + <a download>
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.style.display = 'none';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 5000);
}
